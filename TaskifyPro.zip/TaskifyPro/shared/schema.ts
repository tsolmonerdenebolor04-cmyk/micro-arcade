import { z } from "zod";

// Game-related schemas
export const leaderboardEntrySchema = z.object({
  playerName: z.string().min(1).max(18),
  score: z.number().min(0),
  timestamp: z.number()
});

export const gameStateSchema = z.object({
  tokens: z.number().min(0),
  currentPot: z.number().min(0),
  joined: z.boolean(),
  playing: z.boolean(),
  playerName: z.string().max(18)
});

export type LeaderboardEntry = z.infer<typeof leaderboardEntrySchema>;
export type GameState = z.infer<typeof gameStateSchema>;

// Existing user schemas (keeping for consistency)
export const insertUserSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1)
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = {
  id: string;
  username: string;
  password: string;
};
