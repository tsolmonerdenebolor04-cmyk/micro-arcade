import { useState } from "react";
import { useGameState } from "@/hooks/use-game-state";
import { GameCanvas } from "@/components/game-canvas";
import { Leaderboard } from "@/components/leaderboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Game() {
  const {
    tokens,
    currentPot,
    joined,
    playing,
    playerName,
    setPlayerName,
    gameStatus,
    gameResult,
    joinRound,
    startRound,
    makeClick,
    canJoin,
    canStart,
    canClick
  } = useGameState();

  const [nameInput, setNameInput] = useState("");

  const handleJoinRound = () => {
    if (nameInput.trim()) {
      setPlayerName(nameInput.trim());
      joinRound();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--space-900)' }}>
      <div className="w-full max-w-6xl">
        
        {/* Game Header */}
        <div className="rounded-2xl p-6 shadow-card mb-6" style={{ background: 'var(--space-800)' }}>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
              <h1 className="text-3xl lg:text-4xl font-bold mb-2 text-gradient-cyber">
                Micro Arcade — Skill Crash
              </h1>
              <span className="inline-block px-3 py-1 rounded-full text-sm border" 
                    style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)', color: 'var(--text-secondary)' }}>
                Beta Version
              </span>
            </div>
            <div className="flex items-center gap-4">
              <div className="px-4 py-2 rounded-xl border" 
                   style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)' }}>
                <span style={{ color: 'var(--text-secondary)' }} className="text-sm">Balance:</span>
                <span className="ml-2 font-bold" style={{ color: 'var(--cyber-400)' }} data-testid="balance-tokens">
                  {tokens.toLocaleString()}
                </span>
                <span style={{ color: 'var(--text-secondary)' }} className="ml-1">Tokens</span>
              </div>
            </div>
          </div>
        </div>

        {/* Game Instructions */}
        <div className="rounded-2xl p-6 shadow-card mb-6" style={{ background: 'var(--space-800)' }}>
          <p className="text-lg leading-relaxed">
            Click <em style={{ color: 'var(--cyber-400)' }} className="font-semibold">inside</em> the moving target to score. 
            First correct hit wins the{' '}
            <span className="inline-flex items-center px-3 py-1 rounded-full font-bold shadow-glow-green border"
                  style={{ 
                    background: 'linear-gradient(to right, rgba(156, 255, 138, 0.2), rgba(156, 255, 138, 0.1))',
                    borderColor: 'rgba(156, 255, 138, 0.3)',
                    color: 'var(--neon-green)'
                  }}
                  data-testid="current-pot">
              Pot: {currentPot.toLocaleString()} Tokens
            </span>
          </p>
        </div>

        {/* Player Join Section */}
        <div className="rounded-2xl p-6 shadow-card mb-6" style={{ background: 'var(--space-800)' }}>
          <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
            <div className="flex-1">
              <Input
                type="text"
                placeholder="Enter your player name (for leaderboard)"
                maxLength={18}
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                disabled={joined}
                className="px-4 py-3 rounded-xl focus:ring-1 transition-colors"
                style={{
                  background: 'var(--space-700)',
                  borderColor: 'var(--space-600)',
                  color: 'var(--text-primary)'
                }}
                data-testid="input-player-name"
              />
            </div>
            <Button
              onClick={handleJoinRound}
              disabled={!canJoin || !nameInput.trim()}
              className="px-6 py-3 font-bold rounded-xl transition-all duration-200 hover:scale-105 disabled:hover:scale-100"
              style={{
                background: canJoin && nameInput.trim() 
                  ? 'linear-gradient(to right, var(--cyber-400), var(--cyber-300))'
                  : 'var(--space-600)',
                color: canJoin && nameInput.trim() ? 'var(--space-900)' : 'var(--text-secondary)'
              }}
              data-testid="button-join-round"
            >
              Join Round (25 Tokens)
            </Button>
            <div className="px-4 py-3 rounded-xl text-center sm:text-left whitespace-nowrap border"
                 style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)' }}
                 data-testid="game-status">
              <span style={{ color: 'var(--text-secondary)' }}>Status:</span>
              <span className="ml-2" style={{ color: 'var(--text-primary)' }}>
                {gameStatus}
              </span>
            </div>
          </div>
        </div>

        {/* Game Area */}
        <div className="grid lg:grid-cols-3 gap-6 mb-6">
          
          {/* Game Canvas */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl p-6 shadow-card" style={{ background: 'var(--space-800)' }}>
              <div className="mb-4">
                <h3 className="text-xl font-bold mb-2">Game Arena</h3>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  Watch the moving bar and click when it's inside the green target zone
                </p>
              </div>
              
              <div className="relative mb-6">
                <GameCanvas
                  playing={playing}
                  onGameClick={makeClick}
                  data-testid="game-canvas"
                />
              </div>

              {/* Game Controls */}
              <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
                <Button
                  onClick={startRound}
                  disabled={!canStart}
                  className="px-6 py-3 font-bold rounded-xl transition-all duration-200 hover:scale-105 disabled:hover:scale-100"
                  style={{
                    background: canStart 
                      ? 'linear-gradient(to right, var(--neon-green), #22c55e)'
                      : 'var(--space-600)',
                    color: canStart ? 'var(--space-900)' : 'var(--text-secondary)'
                  }}
                  data-testid="button-start-round"
                >
                  Start Round
                </Button>
                <Button
                  onClick={makeClick}
                  disabled={!canClick}
                  className="px-8 py-3 font-bold rounded-xl text-lg transition-all duration-200 hover:scale-105 disabled:hover:scale-100"
                  style={{
                    background: canClick 
                      ? 'linear-gradient(to right, #ef4444, #f87171)'
                      : 'var(--space-600)',
                    color: canClick ? 'white' : 'var(--text-secondary)'
                  }}
                  data-testid="button-click"
                >
                  CLICK!
                </Button>
                <div className="flex-1 text-center sm:text-left" data-testid="game-result">
                  {gameResult && (
                    <div className="flex items-center gap-2">
                      {gameResult}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-1">
            <Leaderboard />
          </div>
        </div>

        {/* Game Info */}
        <div className="rounded-2xl p-6 shadow-card" style={{ background: 'var(--space-800)' }}>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="px-3 py-1 rounded-full text-sm border" 
                   style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Mode:</span>
                <span className="ml-2 font-semibold" style={{ color: 'var(--cyber-400)' }}>Practice</span>
              </div>
              <div className="px-3 py-1 rounded-full text-sm border" 
                   style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)' }}>
                <span style={{ color: 'var(--text-secondary)' }}>Version:</span>
                <span className="ml-2" style={{ color: 'var(--text-primary)' }}>MVP Beta</span>
              </div>
            </div>
            <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
              Tokens & pot are mock for demo. No real money involved.
            </p>
          </div>
        </div>

        {/* Upcoming Features */}
        <div className="mt-6 rounded-2xl p-6 border" 
             style={{ 
               background: 'linear-gradient(to right, rgba(22, 26, 43, 0.5), rgba(30, 35, 55, 0.3))', 
               borderColor: 'var(--space-600)' 
             }}>
          <div className="text-center">
            <h4 className="text-lg font-bold mb-2" style={{ color: 'var(--cyber-400)' }}>Coming Soon</h4>
            <div className="flex flex-wrap justify-center gap-3 text-sm" style={{ color: 'var(--text-secondary)' }}>
              <span className="px-3 py-1 rounded-full" style={{ background: 'rgba(30, 35, 55, 0.5)' }}>Multiplayer Rounds</span>
              <span className="px-3 py-1 rounded-full" style={{ background: 'rgba(30, 35, 55, 0.5)' }}>New Mini-Games</span>
              <span className="px-3 py-1 rounded-full" style={{ background: 'rgba(30, 35, 55, 0.5)' }}>Tournament Mode</span>
              <span className="px-3 py-1 rounded-full" style={{ background: 'rgba(30, 35, 55, 0.5)' }}>Real Economy</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
