import { useRef, useEffect, useState } from "react";

interface GameCanvasProps {
  playing: boolean;
  onGameClick: () => void;
}

export function GameCanvas({ playing, onGameClick }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number | null>(null);
  const gameStartTimeRef = useRef<number>(0);
  const [target, setTarget] = useState({ x: 0.55, width: 0.10 });
  const [barSpeed, setBarSpeed] = useState(0.85);

  const resetGame = () => {
    // Randomize target position and speed for each round
    setTarget({
      x: 0.25 + Math.random() * 0.5,
      width: 0.08 + Math.random() * 0.06
    });
    setBarSpeed(0.70 + Math.random() * 0.60);
  };

  const drawGameState = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    
    // Clear canvas
    ctx.clearRect(0, 0, W, H);
    
    // Draw rail background
    ctx.fillStyle = "#1E2337";
    ctx.fillRect(40, H/2 - 12, W - 80, 24);
    
    if (playing) {
      // Calculate moving bar position
      const elapsed = (performance.now() - gameStartTimeRef.current) / 1000;
      const phase = (elapsed * barSpeed) % 1;
      const barX = 40 + phase * (W - 80);
      
      // Draw moving bar
      ctx.fillStyle = "#66CCFF";
      ctx.fillRect(barX - 3, H/2 - 18, 6, 36);
    }
    
    // Draw target zone
    const targetX = 40 + target.x * (W - 80);
    const targetWidth = target.width * (W - 80);
    
    ctx.strokeStyle = "#9CFF8A";
    ctx.lineWidth = 3;
    ctx.strokeRect(targetX - targetWidth/2, H/2 - 22, targetWidth, 44);
    
    if (playing) {
      animationFrameRef.current = requestAnimationFrame(drawGameState);
    }
  };

  const handleCanvasClick = () => {
    if (playing) {
      onGameClick();
    }
  };

  useEffect(() => {
    resetGame();
  }, []);

  useEffect(() => {
    if (playing) {
      gameStartTimeRef.current = performance.now();
      drawGameState();
    } else {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
      // Draw static state
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const W = canvas.width;
          const H = canvas.height;
          ctx.clearRect(0, 0, W, H);
          
          // Draw rail background
          ctx.fillStyle = "#1E2337";
          ctx.fillRect(40, H/2 - 12, W - 80, 24);
          
          // Draw target zone
          const targetX = 40 + target.x * (W - 80);
          const targetWidth = target.width * (W - 80);
          ctx.strokeStyle = "#9CFF8A";
          ctx.lineWidth = 3;
          ctx.strokeRect(targetX - targetWidth/2, H/2 - 22, targetWidth, 44);
        }
      }
    }

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [playing, target, barSpeed]);

  // Expose game state for click calculation
  useEffect(() => {
    if (canvasRef.current) {
      (canvasRef.current as any).getGameState = () => ({
        target,
        barSpeed,
        gameStartTime: gameStartTimeRef.current,
        canvas: canvasRef.current
      });
    }
  }, [target, barSpeed]);

  return (
    <canvas
      ref={canvasRef}
      width="760"
      height="220"
      onClick={handleCanvasClick}
      className="w-full h-56 border-2 rounded-xl cursor-pointer"
      style={{ 
        background: 'var(--space-900)', 
        borderColor: 'var(--space-600)' 
      }}
      data-testid="game-canvas"
    />
  );
}
