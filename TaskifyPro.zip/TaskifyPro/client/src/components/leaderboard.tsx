import { useState, useEffect } from "react";
import type { LeaderboardEntry } from "@shared/schema";

export function Leaderboard() {
  const [scores, setScores] = useState<LeaderboardEntry[]>([]);

  const loadScores = () => {
    const data = localStorage.getItem("LEADERBOARD");
    if (data) {
      try {
        const parsed = JSON.parse(data);
        setScores(parsed.slice(0, 10)); // Show top 10
      } catch (error) {
        console.error("Error loading leaderboard:", error);
        setScores([]);
      }
    } else {
      setScores([]);
    }
  };

  const formatTimeAgo = (timestamp: number) => {
    const minutes = Math.floor((Date.now() - timestamp) / 60000);
    if (minutes < 1) return "Just now";
    if (minutes === 1) return "1 min ago";
    return `${minutes} min ago`;
  };

  useEffect(() => {
    loadScores();

    // Listen for storage changes to update leaderboard
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "LEADERBOARD") {
        loadScores();
      }
    };

    window.addEventListener("storage", handleStorageChange);
    
    // Also check periodically for updates (for same-tab updates)
    const interval = setInterval(loadScores, 1000);

    return () => {
      window.removeEventListener("storage", handleStorageChange);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="rounded-2xl p-6 shadow-card h-full" style={{ background: 'var(--space-800)' }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold">Leaderboard</h3>
        <span className="px-2 py-1 rounded text-xs border" 
              style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)', color: 'var(--text-secondary)' }}>
          Local Demo
        </span>
      </div>
      
      <div className="space-y-3 max-h-80 overflow-y-auto" data-testid="leaderboard-entries">
        {scores.length === 0 ? (
          <div className="text-center py-8" style={{ color: 'var(--text-secondary)' }} data-testid="leaderboard-empty">
            <div className="text-4xl mb-2">🎯</div>
            <p>No scores yet!</p>
            <p className="text-sm">Be the first to play</p>
          </div>
        ) : (
          scores.map((entry, index) => (
            <div key={`${entry.playerName}-${entry.timestamp}`} 
                 className="flex items-center justify-between p-3 rounded-lg border" 
                 style={{ background: 'var(--space-700)', borderColor: 'var(--space-600)' }}
                 data-testid={`leaderboard-entry-${index}`}>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                     style={{
                       background: index === 0 
                         ? 'linear-gradient(to right, var(--cyber-400), var(--cyber-300))'
                         : 'var(--space-600)',
                       color: index === 0 ? 'var(--space-900)' : 'var(--text-secondary)'
                     }}
                     data-testid={`leaderboard-rank-${index + 1}`}>
                  {index + 1}
                </div>
                <div>
                  <div className="font-semibold text-sm" data-testid={`leaderboard-name-${index}`}>
                    {entry.playerName}
                  </div>
                  <div className="text-xs" style={{ color: 'var(--text-secondary)' }} data-testid={`leaderboard-time-${index}`}>
                    {formatTimeAgo(entry.timestamp)}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold text-sm" 
                     style={{ 
                       color: index === 0 ? 'var(--neon-green)' : 
                              index === 1 ? 'var(--cyber-400)' : 'var(--text-primary)' 
                     }}
                     data-testid={`leaderboard-score-${index}`}>
                  {entry.score} ms
                </div>
                <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>from center</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
