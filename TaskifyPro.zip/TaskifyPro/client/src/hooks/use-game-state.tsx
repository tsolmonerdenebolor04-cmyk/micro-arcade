import { useState, useEffect, useRef } from "react";
import type { LeaderboardEntry } from "@shared/schema";

const BUY_IN = 25;
const INITIAL_TOKENS = 1000;
const INITIAL_POT = 250;

export function useGameState() {
  const [tokens, setTokens] = useState(() => {
    const saved = localStorage.getItem("TOKENS");
    return saved ? parseInt(saved) : INITIAL_TOKENS;
  });
  
  const [currentPot, setCurrentPot] = useState(INITIAL_POT);
  const [joined, setJoined] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [playerName, setPlayerName] = useState("");
  const [gameStatus, setGameStatus] = useState("Waiting to join...");
  const [gameResult, setGameResult] = useState<React.ReactNode | null>(null);

  // Game state refs for canvas access
  const gameCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const saveScore = (name: string, score: number) => {
    const entry: LeaderboardEntry = {
      playerName: name,
      score: score,
      timestamp: Date.now()
    };
    
    const data = localStorage.getItem("LEADERBOARD");
    const scores: LeaderboardEntry[] = data ? JSON.parse(data) : [];
    scores.push(entry);
    scores.sort((a, b) => a.score - b.score); // Lower is better
    
    localStorage.setItem("LEADERBOARD", JSON.stringify(scores.slice(0, 50)));
  };

  const joinRound = () => {
    if (joined) {
      setGameStatus("Already joined this round");
      return;
    }
    
    if (tokens < BUY_IN) {
      setGameStatus("Not enough tokens");
      return;
    }
    
    if (!playerName.trim()) {
      setGameStatus("Enter your name first");
      return;
    }
    
    const newTokens = tokens - BUY_IN;
    setTokens(newTokens);
    localStorage.setItem("TOKENS", newTokens.toString());
    
    setCurrentPot(prev => prev + BUY_IN);
    setJoined(true);
    setGameStatus(`Joined! ${newTokens.toLocaleString()} tokens remaining`);
    setGameResult(null);
  };

  const startRound = () => {
    if (!joined) {
      setGameStatus("Join the round first");
      return;
    }
    
    if (playing) return;
    
    setPlaying(true);
    setGameStatus("Round live! Click when the bar is in the green zone!");
    setGameResult(null);
  };

  const makeClick = () => {
    if (!playing) return;
    
    setPlaying(false);
    
    // Get game state from canvas
    const canvas = document.querySelector('[data-testid="game-canvas"]') as any;
    if (!canvas?.getGameState) return;
    
    const { target, barSpeed, gameStartTime, canvas: canvasEl } = canvas.getGameState();
    
    const W = canvasEl.width;
    const elapsed = (performance.now() - gameStartTime) / 1000;
    const phase = (elapsed * barSpeed) % 1;
    const barX = 40 + phase * (W - 80);
    
    // Calculate accuracy
    const targetX = 40 + target.x * (W - 80);
    const targetWidth = target.width * (W - 80);
    const distanceFromCenter = Math.abs(barX - targetX);
    const isHit = distanceFromCenter <= targetWidth / 2;
    
    // Convert to "ms from center" for scoring
    const msFromCenter = Math.round(distanceFromCenter * (1000 / (W - 80)) * 100);
    
    if (isHit) {
      // Winner!
      saveScore(playerName, msFromCenter);
      const newTokens = tokens + currentPot;
      setTokens(newTokens);
      localStorage.setItem("TOKENS", newTokens.toString());
      
      setGameResult(
        <>
          <span className="text-2xl">🎉</span>
          <span className="font-bold" style={{ color: 'var(--neon-green)' }}>HIT!</span>
          <span style={{ color: 'var(--text-primary)' }}>
            {playerName} wins {currentPot.toLocaleString()} tokens
          </span>
          <span style={{ color: 'var(--text-secondary)' }}>• {msFromCenter}ms accuracy</span>
        </>
      );
      
      setCurrentPot(INITIAL_POT);
      setGameStatus(`Victory! ${newTokens.toLocaleString()} tokens total`);
      
      // Reset for next round
      setJoined(false);
      
    } else {
      setGameResult(
        <>
          <span className="text-2xl">❌</span>
          <span className="font-bold" style={{ color: 'var(--neon-red)' }}>Missed!</span>
          <span style={{ color: 'var(--text-secondary)' }}>
            Off by {msFromCenter}ms • Try again next round
          </span>
        </>
      );
      setGameStatus("Better luck next time!");
    }
  };

  // Update status based on token count
  useEffect(() => {
    if (!joined && !playing) {
      setGameStatus(`${tokens.toLocaleString()} tokens available • Join a round to play`);
    }
  }, [tokens, joined, playing]);

  return {
    tokens,
    currentPot,
    joined,
    playing,
    playerName,
    setPlayerName,
    gameStatus,
    gameResult,
    joinRound,
    startRound,
    makeClick,
    canJoin: !joined && tokens >= BUY_IN,
    canStart: joined && !playing,
    canClick: playing
  };
}
