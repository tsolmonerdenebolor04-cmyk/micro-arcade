# Overview

This is a skill-based arcade game called "Micro Arcade — Skill Crash" built as a web application. The game features a timing-based challenge where players must click inside a moving target to score points. Players buy into rounds with virtual tokens, compete for a pot, and their scores are tracked on a local leaderboard. The application is built with React on the frontend and Express.js on the backend, designed as a full-stack web application with modern UI components.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks with custom game state management via `useGameState` hook
- **UI Components**: Radix UI primitives with shadcn/ui component system for consistent, accessible design
- **Styling**: Tailwind CSS with custom CSS variables for theming, including dark mode support
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Framework**: Express.js with TypeScript for server-side logic
- **Storage Interface**: Abstracted storage layer with in-memory implementation (`MemStorage`)
- **API Structure**: RESTful API design with `/api` prefix for all endpoints
- **Middleware**: Request logging, JSON parsing, and error handling built-in

## Data Storage
- **Primary Storage**: Drizzle ORM configured for PostgreSQL database operations
- **Local Storage**: Browser localStorage for game state persistence (tokens, leaderboard)
- **Schema Management**: Shared TypeScript schemas using Zod for validation
- **Database Migrations**: Drizzle Kit for schema migrations and database management

## Game Architecture
- **Canvas Rendering**: HTML5 Canvas for real-time game graphics and animations
- **Game State**: Local state management with persistence to localStorage
- **Timing System**: Performance.now() for precise timing measurements
- **Score Calculation**: Distance-based scoring system measuring accuracy from target center

## External Dependencies

### Database & ORM
- **Neon Database**: Serverless PostgreSQL database (@neondatabase/serverless)
- **Drizzle ORM**: Type-safe database operations with schema management
- **Drizzle Kit**: Database migration and schema management tools

### UI & Styling
- **Radix UI**: Comprehensive set of accessible, unstyled UI primitives
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Lucide React**: Icon library for consistent iconography

### Development & Build Tools
- **Vite**: Fast build tool with hot module replacement for development
- **TypeScript**: Static type checking for better code quality
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment integration with error handling

### State Management & Data Fetching
- **TanStack Query**: Server state management and caching for API calls
- **React Hook Form**: Form state management with validation
- **Zod**: Runtime type validation and schema definition

### Session & Authentication
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **Express Session**: Session management middleware (configured but not actively used in current implementation)